#include <vector>

void Solve(int N);

int Query(const std::vector<int> &p);
void Answer(int a, int b);
